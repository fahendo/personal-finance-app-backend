package com.fabio.personalfinance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonalFinanceAppBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
